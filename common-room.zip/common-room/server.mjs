import http from 'node:http';
import { DatabaseSync } from 'node:sqlite';
import { randomBytes, createHash } from 'node:crypto';
import { mkdirSync, readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = dirname(fileURLToPath(import.meta.url));
const databasePath = process.env.DATABASE_PATH || join(root, 'data', 'board.sqlite');
mkdirSync(dirname(databasePath), { recursive: true, mode: 0o700 });
const db = new DatabaseSync(databasePath);
db.exec(`PRAGMA journal_mode = DELETE; PRAGMA secure_delete = ON;
  CREATE TABLE IF NOT EXISTS messages (
    id TEXT PRIMARY KEY, owner TEXT NOT NULL, body TEXT NOT NULL,
    kind TEXT NOT NULL CHECK(kind IN ('text','code')),
    language TEXT NOT NULL, created_at INTEGER NOT NULL, expires_at INTEGER NOT NULL
  );
  CREATE INDEX IF NOT EXISTS messages_expiry ON messages(expires_at);
  CREATE INDEX IF NOT EXISTS messages_created ON messages(created_at DESC, id DESC);`);
const TTL = 24 * 60 * 60 * 1000;
const languages = new Set(['plaintext', 'cpp', 'java', 'python', 'javascript', 'html', 'sql', 'other']);
const hash = value => createHash('sha256').update(value).digest('hex');
const cleanup = () => db.prepare('DELETE FROM messages WHERE expires_at <= ?').run(Date.now());
cleanup();
const interval = setInterval(cleanup, 30_000);
interval.unref();
const limits = new Map();
const rateSalt = randomBytes(32).toString('hex');

function limited(key, max) {
  const now = Date.now();
  let item = limits.get(key);
  if (!item || now - item.start >= 60_000) { item = { start: now, count: 0 }; limits.set(key, item); }
  if (limits.size > 10_000) for (const [k, v] of limits) if (now - v.start >= 60_000) limits.delete(k);
  item.count++;
  return item.count > max;
}
function json(res, status, value) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(value));
}
function session(req, res) {
  const match = (req.headers.cookie || '').match(/(?:^|;\s*)board_session=([a-f0-9]{64})(?:;|$)/);
  const token = match?.[1] || randomBytes(32).toString('hex');
  if (!match) res.setHeader('Set-Cookie', cookie(token));
  return hash(token);
}
function cookie(token, clear = false) {
  return `board_session=${token}; Path=/; HttpOnly; SameSite=Strict${process.env.COOKIE_SECURE === 'true' ? '; Secure' : ''}${clear ? '; Max-Age=0' : ''}`;
}
async function body(req) {
  let size = 0;
  const chunks = [];
  for await (const chunk of req) {
    size += chunk.length;
    if (size > 48_000) throw Object.assign(new Error('Post is too large.'), { status: 413 });
    chunks.push(chunk);
  }
  try { return JSON.parse(Buffer.concat(chunks).toString('utf8')); }
  catch { throw Object.assign(new Error('Send valid JSON.'), { status: 400 }); }
}
function sameOrigin(req) {
  let origin;
  try { origin = new URL(req.headers.origin); } catch { return false; }
  if (process.env.PUBLIC_ORIGIN) return origin.origin === process.env.PUBLIC_ORIGIN;
  return origin.host === req.headers.host && ['http:', 'https:'].includes(origin.protocol);
}
const assets = {
  '/': ['index.html', 'text/html; charset=utf-8'],
  '/app.js': ['app.js', 'text/javascript; charset=utf-8'],
  '/style.css': ['style.css', 'text/css; charset=utf-8'],
  '/icon.svg': ['icon.svg', 'image/svg+xml'],
};

const server = http.createServer(async (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'");
  try {
    const url = new URL(req.url, 'http://localhost');
    if (assets[url.pathname] && ['GET', 'HEAD'].includes(req.method)) {
      const [file, type] = assets[url.pathname];
      res.writeHead(200, { 'Content-Type': type });
      return res.end(req.method === 'HEAD' ? undefined : readFileSync(join(root, 'public', file)));
    }
    if (!url.pathname.startsWith('/api/')) return json(res, 404, { error: 'Page not found.' });
    if (!['GET', 'POST', 'DELETE'].includes(req.method)) return json(res, 405, { error: 'Posts cannot be edited.' });
    if (req.method !== 'GET' && !sameOrigin(req)) return json(res, 403, { error: 'Request must come from this website.' });
    cleanup();
    const owner = session(req, res);
    if (url.pathname === '/api/session/end' && req.method === 'POST') {
      res.setHeader('Set-Cookie', cookie('', true));
      return json(res, 200, { ok: true });
    }
    if (url.pathname === '/api/messages' && req.method === 'GET') {
      const q = (url.searchParams.get('q') || '').trim().slice(0, 200);
      const kind = ['text','code'].includes(url.searchParams.get('kind')) ? url.searchParams.get('kind') : '';
      const before = url.searchParams.get('before') || '';
      let cursor = null;
      if (before) {
        try { cursor = JSON.parse(Buffer.from(before, 'base64url').toString()); } catch {}
        if (!cursor || !Number.isSafeInteger(cursor.time) || !/^[a-f0-9]{32}$/.test(cursor.id || '')) return json(res, 400, { error: 'Invalid page cursor.' });
      }
      const conditions = ['expires_at > ?'];
      const params = [Date.now()];
      if (q) { conditions.push('instr(lower(body), lower(?)) > 0'); params.push(q); }
      if (kind) { conditions.push('kind = ?'); params.push(kind); }
      if (cursor) { conditions.push('(created_at < ? OR (created_at = ? AND id < ?))'); params.push(cursor.time, cursor.time, cursor.id); }
      const rows = db.prepare(`SELECT * FROM messages WHERE ${conditions.join(' AND ')} ORDER BY created_at DESC, id DESC LIMIT 101`).all(...params);
      const more = rows.length > 100;
      const visible = rows.slice(0, 100);
      const last = visible.at(-1);
      return json(res, 200, {
        messages: visible.map(({ owner: postOwner, ...post }) => ({ ...post, mine: postOwner === owner })),
        cursor: more ? Buffer.from(JSON.stringify({ time: last.created_at, id: last.id })).toString('base64url') : null,
        total: db.prepare('SELECT COUNT(*) AS count FROM messages WHERE expires_at > ?').get(Date.now()).count,
        server_time: Date.now()
      });
    }
    if (url.pathname === '/api/messages' && req.method === 'POST') {
      if (!(req.headers['content-type'] || '').startsWith('application/json')) return json(res, 415, { error: 'Send JSON content.' });
      const value = await body(req);
      if (!value || typeof value.body !== 'string' || !value.body.trim() || value.body.length > 10_000 || !['text','code'].includes(value.kind)) return json(res, 400, { error: 'Write a text or code post between 1 and 10,000 characters.' });
      if (value.language && !languages.has(value.language)) return json(res, 400, { error: 'Choose a supported language label.' });
      const ipKey = hash(rateSalt + req.socket.remoteAddress);
      if (limited('session:' + owner, 15) || limited('ip:' + ipKey, 60)) {
        res.setHeader('Retry-After', '60');
        return json(res, 429, { error: 'A few too many posts. Please wait a minute.' });
      }
      const now = Date.now();
      const id = randomBytes(16).toString('hex');
      db.prepare('INSERT INTO messages (id, owner, body, kind, language, created_at, expires_at) VALUES (?, ?, ?, ?, ?, ?, ?)')
        .run(id, owner, value.body, value.kind, value.kind === 'code' ? value.language || 'plaintext' : 'plaintext', now, now + TTL);
      return json(res, 201, { id, created_at: now, expires_at: now + TTL });
    }
    const match = url.pathname.match(/^\/api\/messages\/([a-f0-9]{32})$/);
    if (match && req.method === 'DELETE') {
      const result = db.prepare('DELETE FROM messages WHERE id = ? AND owner = ? AND expires_at > ?').run(match[1], owner, Date.now());
      return result.changes ? json(res, 200, { ok: true }) : json(res, 404, { error: 'Post not found, expired, or belongs to another session.' });
    }
    return json(res, 404, { error: 'Not found.' });
  } catch (err) {
    json(res, err.status || 500, { error: err.status ? err.message : 'Something went wrong. Please try again.' });
  }
});
server.requestTimeout = 15_000;
server.headersTimeout = 10_000;
server.listen(Number(process.env.PORT || 3000), process.env.HOST || '127.0.0.1', () => {
  console.log(`Common Room is running at http://${process.env.HOST || '127.0.0.1'}:${server.address().port}`);
});
function stop() { clearInterval(interval); server.close(() => { db.close(); process.exit(0); }); }
process.on('SIGINT', stop);
process.on('SIGTERM', stop);
