const $ = id => document.getElementById(id);
let kind = 'text', filter = 'all', cursor = null, posts = [], clockOffset = 0;
let controller, loadVersion = 0, toastTimer, searchTimer, posting = false, loadingMore = false, endingSession = false;
const languageNames = { plaintext:'Plain text', cpp:'C++', java:'Java', python:'Python', javascript:'JavaScript', html:'HTML', sql:'SQL', other:'Code' };
const now = () => Date.now() + clockOffset;
const node = (tag, className, text) => { const el = document.createElement(tag); if(className) el.className = className; if(text !== undefined) el.textContent = text; return el; };
function toast(message) { $('toast').textContent = message; $('toast').hidden = false; clearTimeout(toastTimer); toastTimer = setTimeout(() => $('toast').hidden = true, 3500); }
async function api(path, options = {}) {
  const result = await fetch(path, { ...options, credentials:'same-origin', cache:'no-store', headers:{ 'Content-Type':'application/json', ...options.headers } });
  const value = await result.json();
  if (!result.ok) throw new Error(value.error || 'Unable to connect. Please try again.');
  return value;
}
function setConnection(ok) { $('connection').classList.toggle('offline', !ok); $('connection').replaceChildren(node('span','dot'), document.createTextNode(ok ? 'Updates every 5s' : 'Reconnecting')); }
function setKind(next) {
  kind = next;
  $('type-text').classList.toggle('selected', kind === 'text'); $('type-code').classList.toggle('selected', kind === 'code');
  $('type-text').setAttribute('aria-pressed', String(kind === 'text')); $('type-code').setAttribute('aria-pressed', String(kind === 'code'));
  $('language-wrap').hidden = kind !== 'code'; $('body').classList.toggle('code-input', kind === 'code');
  $('body').dir = kind === 'code' ? 'ltr' : 'auto';
  $('body').placeholder = kind === 'code' ? '// Paste your code here…' : 'What would you like to share?';
}
$('type-text').onclick = () => setKind('text'); $('type-code').onclick = () => setKind('code');
$('body').addEventListener('input', () => $('character-count').textContent = `${$('body').value.length.toLocaleString()} / 10,000`);
$('body').addEventListener('keydown', event => {
  if (kind === 'code' && event.key === 'Tab' && !event.shiftKey) { event.preventDefault(); $('body').setRangeText('  ', $('body').selectionStart, $('body').selectionEnd, 'end'); $('body').dispatchEvent(new Event('input')); }
  if ((event.ctrlKey || event.metaKey) && event.key === 'Enter') { event.preventDefault(); $('post-form').requestSubmit(); }
});
function relative(time) { const minutes = Math.max(0, Math.floor((now() - time) / 60000)); return minutes < 1 ? 'Just now' : minutes < 60 ? `${minutes} min ago` : `${Math.floor(minutes/60)}h ago`; }
function remaining(time) { const minutes = Math.max(1, Math.ceil((time - now())/60000)); const hours = Math.floor(minutes/60); return hours ? `${hours}h ${minutes%60}m left` : `${minutes}m left`; }
function confirmAction(title, description, label) {
  return new Promise(resolve => {
    $('confirm-title').textContent = title; $('confirm-description').textContent = description; $('confirm-yes').textContent = label;
    const dialog = $('confirm-dialog');
    dialog.returnValue = '';
    const onClose = () => resolve(dialog.returnValue === 'yes');
    dialog.addEventListener('close', onClose, { once:true });
    $('confirm-cancel').onclick = () => dialog.close('no'); $('confirm-yes').onclick = () => dialog.close('yes'); dialog.showModal();
  });
}
async function copyPost(post, button) {
  try {
    if (navigator.clipboard && window.isSecureContext) await navigator.clipboard.writeText(post.body);
    else {
      const field = node('textarea','sr-only'); field.value = post.body; document.body.append(field); field.select();
      const ok = document.execCommand('copy'); field.remove(); if (!ok) throw new Error();
    }
    button.textContent = '✓ Copied'; setTimeout(() => button.textContent = post.kind === 'code' ? '⧉ Copy code' : '⧉ Copy', 1800);
  } catch { toast('Copy unavailable. Select the text and copy it manually.'); }
}
function render() {
  const container = $('posts'); const active = document.activeElement;
  const focusedId = active?.closest?.('[data-post-id]')?.dataset.postId;
  const focusedAction = active?.dataset?.action;
  posts = posts.filter(post => post.expires_at > now());
  const children = posts.map(post => {
    const article = node('article','post'); article.dataset.postId = post.id;
    const meta = node('div','post-meta'), type = node('div','post-type', post.kind === 'code' ? `</> ${languageNames[post.language] || 'Code'}` : '○ A thought');
    if(post.mine) type.append(node('span','mine-tag','Your post'));
    const time = node('time','post-time',relative(post.created_at)); time.dateTime = new Date(post.created_at).toISOString(); time.title = new Date(post.created_at).toLocaleString();
    meta.append(type,time); article.append(meta);
    if(post.kind === 'code') { const pre = node('pre'); pre.append(node('code','',post.body)); article.append(pre); }
    else { const text = node('p','post-body',post.body); text.dir = 'auto'; article.append(text); }
    const bottom = node('div','post-bottom'); const expiry = node('span','expiry',`◷ ${remaining(post.expires_at)}`); expiry.dataset.expires = post.expires_at;
    const actions = node('div','post-actions');
    if(post.mine) { const remove = node('button','delete','Delete'); remove.type = 'button'; remove.dataset.action='delete'; remove.setAttribute('aria-label','Delete your post'); remove.onclick = async () => {
      if (!await confirmAction('Delete this post?', 'It will disappear from the board for everyone. This cannot be undone.', 'Delete post')) return;
      remove.disabled = true;
      try { await api(`/api/messages/${post.id}`, { method:'DELETE' }); posts = posts.filter(item => item.id !== post.id); render(); toast('Post deleted.'); await load(); }
      catch(err) { toast(err.message); remove.disabled = false; }
    }; actions.append(remove); }
    const copy = node('button','',post.kind === 'code' ? '⧉ Copy code' : '⧉ Copy'); copy.type='button'; copy.dataset.action='copy'; copy.onclick = () => copyPost(post,copy); actions.append(copy);
    bottom.append(expiry,actions); article.append(bottom); return article;
  });
  if(!children.length) {
    const empty = node('div','empty-state'); empty.append(node('div','empty-icon','✳'),node('h3','', $('search').value || filter !== 'all' ? 'Nothing here just yet.' : 'Be the first in the room.'),node('p','', $('search').value || filter !== 'all' ? 'Try another search or switch back to Everything.' : 'A question, a useful snippet, a fresh idea. Your first post starts the conversation.')); children.push(empty);
  }
  container.replaceChildren(...children); container.setAttribute('aria-busy','false');
  $('load-more').hidden = !cursor;
  if(focusedId && focusedAction) container.querySelector(`[data-post-id="${focusedId}"] [data-action="${focusedAction}"]`)?.focus({preventScroll:true});
}
async function load(append = false) {
  if (loadingMore && !append) return;
  if(append) loadingMore = true;
  const version = ++loadVersion;
  controller?.abort(); controller = new AbortController();
  const params = new URLSearchParams({ q:$('search').value.trim(), kind:filter === 'all' ? '' : filter });
  if(append && cursor) params.set('before', cursor);
  const requestedOffset = append;
  const previousCursor = cursor;
  try {
    const signal = controller.signal;
    const value = await api(`/api/messages?${params}`, {signal});
    // Refresh every loaded page, so polling neither drops older posts nor keeps deleted ones.
    if(!append) {
      const pages = Math.max(1, Math.ceil(posts.length / 100));
      for(let page=1; page<pages && value.cursor; page++) {
        params.set('before',value.cursor);
        const extra = await api(`/api/messages?${params}`,{signal});
        value.messages.push(...extra.messages); value.cursor=extra.cursor;
      }
    }
    if(version !== loadVersion) return;
    clockOffset = value.server_time - Date.now(); cursor = value.cursor;
    const merged = requestedOffset ? [...posts,...value.messages] : value.messages;
    const fresh = [...new Map(merged.map(p=>[p.id,p])).values()];
    const changed = JSON.stringify(fresh) !== JSON.stringify(posts);
    posts = fresh;
    $('post-count').textContent = value.total; $('board-error').hidden = true; setConnection(true);
    // Keep selections and horizontal code scroll intact when nothing changed.
    if(changed || $('posts').getAttribute('aria-busy') === 'true' || !$('posts').querySelector('.post, .empty-state')) render();
    $('load-more').hidden = !cursor;
  } catch(err) {
    if(err.name === 'AbortError') return;
    cursor = previousCursor; setConnection(false); $('board-error').textContent = 'Could not refresh the room. Your message draft is safe. Retrying shortly.'; $('board-error').hidden = false;
    if($('posts').getAttribute('aria-busy') === 'true') { $('posts').replaceChildren(node('div','loading-state','The room is temporarily unavailable.')); $('posts').setAttribute('aria-busy','false'); }
  } finally { if(append) loadingMore = false; $('load-more').disabled = false; }
}
$('post-form').addEventListener('submit', async event => {
  event.preventDefault(); if(posting) return; if(!$('body').value.trim()) { $('body').focus(); return; }
  posting = true; $('send').disabled = true; $('form-error').hidden = true;
  const draft = $('body').value;
  try {
    await api('/api/messages', {method:'POST',body:JSON.stringify({body:draft, kind, language:$('language').value})});
    if($('body').value === draft) { $('body').value=''; $('body').dispatchEvent(new Event('input')); }
    $('search').value=''; filter='all'; updateFilters(); toast('Posted. Here for the next 24 hours.'); await load();
  } catch(err) { $('form-error').textContent=err.message; $('form-error').hidden=false; }
  finally { posting=false; $('send').disabled=false; }
});
function updateFilters() { document.querySelectorAll('[data-filter]').forEach(button=>{ const active = button.dataset.filter===filter; button.classList.toggle('active',active); button.setAttribute('aria-pressed',String(active)); }); }
document.querySelectorAll('[data-filter]').forEach(button => button.onclick=()=>{ filter=button.dataset.filter; updateFilters(); load(); });
$('search').addEventListener('input',()=>{clearTimeout(searchTimer); searchTimer=setTimeout(()=>load(),220);});
$('load-more').onclick=()=>{ $('load-more').disabled=true; load(true); };
$('about-open').onclick=()=>$('about-dialog').showModal(); $('privacy-open').onclick=()=>$('privacy-dialog').showModal();
document.querySelectorAll('[data-close]').forEach(button=>button.onclick=()=>button.closest('dialog').close());
$('end-session').onclick=async()=>{
  if(!await confirmAction('Leave this session?', 'Your posts stay until they expire, but you will lose the ability to delete them. Your unsent draft will be cleared. Use this before leaving a shared computer.', 'End session')) return;
  $('end-session').disabled=true; endingSession=true;
  controller?.abort(); ++loadVersion;
  try { await api('/api/session/end',{method:'POST'}); $('body').value=''; $('body').dispatchEvent(new Event('input')); $('language').value='plaintext'; $('search').value=''; setKind('text'); filter='all'; updateFilters(); toast('Session ended. Your draft and deletion access are cleared.'); await load(); }
  catch(err){toast(err.message);} finally{$('end-session').disabled=false; endingSession=false;}
};
setInterval(()=>{if(!document.hidden && !loadingMore && !posting && !endingSession) load();},5000);
setInterval(()=>{
  if(posts.some(p=>p.expires_at<=now())) {render(); load();}
  document.querySelectorAll('[data-expires]').forEach(el=>el.textContent=`◷ ${remaining(Number(el.dataset.expires))}`);
},1000);
document.addEventListener('visibilitychange',()=>{if(!document.hidden) load();});
load();
