# Common Room

A working anonymous board for text and code, with one shared SQLite database. No third-party dependencies or paid API is required. Node.js 24 or newer is required.

## Run on your computer

1. Install Node.js 24 LTS from https://nodejs.org/ if it is not installed.
2. Open a terminal in this folder.
3. Run `npm start`.
4. Open **http://localhost:3000** in a browser.

No `npm install` step is needed. Keep the terminal open while using the board. Other browsers connected to this same server see the same board; separate installations have separate databases.

Run `npm test` for server integration tests and `npm run check` for JavaScript syntax checks.

## Features

- One shared board; no public usernames, account registration, or AI answers.
- Text and code posts, with optional language labels and preserved formatting.
- Search, text/code filters, copy buttons, pagination, and refresh every five seconds.
- No post editing. Only the browser session that created a post can delete it.
- Posts expire individually 24 hours after the server receives them. Expired posts are excluded on every API read, hidden locally on a timer, and deleted from storage every 30 seconds while running, at startup, and on API requests.
- End session clears the cookie and unsent draft. Existing posts remain until they expire; the browser loses deletion access to them.
- Input validation, same-origin write checks, HttpOnly/SameSite session cookies, basic posting rate limits, parameterized queries, and security headers.
- Responsive desktop/mobile layout with keyboard-accessible forms, dialogs, filters, status messages, and plain text rendering of user content.

## Privacy limits

Anonymous here means no names are shown. It does not guarantee that users or operators are untraceable. The app stores a hash of a random session token alongside each post; the original token stays in an HttpOnly browser cookie. No IP addresses are written into the message database. Short-lived, salted hashes of connection addresses are used in memory for rate limiting.

Post expiry is not a guarantee that screenshots, copies, network/provider logs, or backups disappear. SQLite secure deletion is enabled, but storage systems can still retain snapshots. While the service is stopped, its cleanup timer cannot run; startup cleanup deletes overdue records before it serves requests. Live browser displays may need a refresh after a device sleeps or loses connectivity.

## Hosting

This checkout is currently **local only**. A public link has not been deployed. The Sites plugin's required local publishing helpers and starter were unavailable in the session, so no hosted Site was registered.

Deploy the server on a Node.js 24+ host with persistent disk and HTTPS. Set:

- `HOST=0.0.0.0` to accept external connections.
- `PORT` to the host's supplied port (default `3000`).
- `DATABASE_PATH` to a file on the persistent disk (default `data/board.sqlite`).
- `PUBLIC_ORIGIN` to the exact external HTTPS origin, e.g. `https://your-board.example`.
- `COOKIE_SECURE=true` for HTTPS deployments.

Run only one application instance against this local SQLite database. Do not deploy this as an ephemeral filesystem-only serverless function. No hosting subscription, domain, or paid account was created. Abuse controls and owner moderation would need further work before broad public promotion; this first version has per-session/address posting limits but no owner moderation console.

The proposed name **Common Room** is a placeholder and can be changed.

## Verification

Integration tests cover shared visibility, ownership, refusal to edit, session reset, expiry purge, validation, cross-origin writes, search, pagination, rate limiting, and asset delivery. Browser visual/interaction QA has not been performed in this environment.
