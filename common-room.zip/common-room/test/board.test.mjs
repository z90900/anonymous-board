import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { DatabaseSync } from 'node:sqlite';

const dir = mkdtempSync(join(tmpdir(),'common-room-'));
const databasePath = join(dir,'test.sqlite');
let processHandle, origin;
const delay = ms => new Promise(resolve=>setTimeout(resolve,ms));
before(async()=>{
  processHandle = spawn(process.execPath,['server.mjs'],{cwd:new URL('..',import.meta.url),env:{...process.env,PORT:'0',DATABASE_PATH:databasePath},stdio:['ignore','pipe','pipe']});
  origin = await new Promise((resolve,reject)=>{
    const timer=setTimeout(()=>reject(new Error('Server startup timed out')),10000);
    processHandle.once('error',error=>{clearTimeout(timer);reject(error);});
    processHandle.once('exit',code=>{clearTimeout(timer);reject(new Error(`Server exited: ${code}`));});
    processHandle.stdout.on('data',chunk=>{const found=chunk.toString().match(/http:\/\/127\.0\.0\.1:\d+/);if(found){clearTimeout(timer);resolve(found[0]);}});
  });
});
after(async()=>{processHandle?.kill('SIGTERM');if(processHandle?.exitCode===null)await new Promise(resolve=>processHandle.once('exit',resolve));rmSync(dir,{recursive:true,force:true});});
function client() {
  let cookie='';
  return async(path,method='GET',data,extra={})=>{
    const response=await fetch(origin+path,{method,headers:{Origin:origin,'Content-Type':'application/json',...(cookie?{Cookie:cookie}:{}),...extra},body:data===undefined?undefined:JSON.stringify(data)});
    const setCookie=response.headers.get('set-cookie');if(setCookie)cookie=setCookie.split(';')[0];
    return {status:response.status,headers:response.headers,data:await response.json()};
  };
}
test('anonymous users share posts; ownership is private and enforced',async()=>{
  const alice=client(),bob=client(); await alice('/api/messages');await bob('/api/messages');
  const content='#include <iostream>\nint main() {\n  std::cout << "سڵاو";\n}\n';
  const created=await alice('/api/messages','POST',{kind:'code',language:'cpp',body:content});
  assert.equal(created.status,201);assert.equal(created.data.expires_at-created.data.created_at,86400000);
  const own=await alice('/api/messages');const theirs=await bob('/api/messages');
  const a=own.data.messages.find(p=>p.id===created.data.id),b=theirs.data.messages.find(p=>p.id===created.data.id);
  assert.equal(a.mine,true);assert.equal(b.mine,false);assert.equal(a.body,content);
  assert.equal('owner' in a,false);assert.equal('username' in a,false);
  assert.match(own.headers.get('set-cookie')||'',/^$/);assert.equal(own.headers.get('cache-control'),'no-store');
  assert.equal((await bob('/api/messages/'+a.id,'DELETE')).status,404);
  assert.equal((await alice('/api/messages/'+a.id,'PATCH',{body:'edited'})).status,405);
  assert.equal((await alice('/api/messages/'+a.id,'DELETE')).status,200);
  assert.equal((await bob('/api/messages')).data.messages.some(p=>p.id===a.id),false);
});
test('end session revokes browser deletion access without deleting posts',async()=>{
  const user=client();await user('/api/messages');
  const post=await user('/api/messages','POST',{kind:'text',body:'Before leaving the lab'});
  const ended=await user('/api/session/end','POST');assert.equal(ended.status,200);assert.match(ended.headers.get('set-cookie'),/Max-Age=0/);
  const messages=await user('/api/messages');assert.equal(messages.data.messages.find(p=>p.id===post.data.id).mine,false);
  assert.equal((await user('/api/messages/'+post.data.id,'DELETE')).status,404);
});
test('server rejects expired posts and physically purges them on reads',async()=>{
  const database=new DatabaseSync(databasePath);
  const id='f'.repeat(32);
  database.prepare('INSERT INTO messages VALUES (?, ?, ?, ?, ?, ?, ?)').run(id,'not-a-browser','Expired secret','text','plaintext',Date.now()-86400001,Date.now()+50);
  await delay(100);
  const user=client();const value=await user('/api/messages');assert.equal(value.data.messages.some(p=>p.id===id),false);
  assert.equal(database.prepare('SELECT COUNT(*) AS count FROM messages WHERE id = ?').get(id).count,0);database.close();
});
test('validation and origin checks reject malformed or cross-site writes',async()=>{
  const user=client();await user('/api/messages');
  assert.equal((await user('/api/messages','POST',{kind:'text',body:'no'},{Origin:'https://other.example'})).status,403);
  for(const value of [null,{kind:'text',body:'   '},{kind:'invalid',body:'hello'},{kind:'code',body:'x',language:'bad'},{kind:'text',body:'x'.repeat(10001)}]) assert.equal((await user('/api/messages','POST',value)).status,400);
  assert.equal((await user('/api/messages','POST',{kind:'text',body:'x'},{'Content-Type':'text/plain'})).status,415);
  assert.equal((await user('/api/messages','POST',{kind:'text',body:'x'.repeat(50000)})).status,413);
});
test('search, filters, and cursor pagination preserve Unicode and query safety',async()=>{
  const user=client();await user('/api/messages');
  await user('/api/messages','POST',{kind:'text',body:'سڵاو — arrays explanation'});
  let value=await user('/api/messages?q='+encodeURIComponent('سڵاو')+'&kind=text');assert.equal(value.data.messages.length,1);
  assert.equal((await user('/api/messages?q='+encodeURIComponent("' OR 1=1 --"))).data.messages.length,0);
  assert.equal((await user('/api/messages?before=invalid')).status,400);
  const database=new DatabaseSync(databasePath),start=Date.now();
  for(let i=0;i<105;i++)database.prepare('INSERT INTO messages VALUES (?, ?, ?, ?, ?, ?, ?)').run(i.toString(16).padStart(32,'0'),'test','page-fixture '+i,'code','plaintext',start-i, start+86400000);
  database.close();
  value=await user('/api/messages?q=page-fixture');assert.equal(value.data.messages.length,100);assert.ok(value.data.cursor);
  const next=await user('/api/messages?q=page-fixture&before='+value.data.cursor);assert.equal(next.data.messages.length,5);assert.equal(next.data.cursor,null);
  assert.equal(new Set([...value.data.messages,...next.data.messages].map(p=>p.id)).size,105);
});
test('rapid posting is limited',async()=>{
  const user=client();await user('/api/messages');let last;
  for(let i=0;i<16;i++)last=await user('/api/messages','POST',{kind:'text',body:'rate check'});
  assert.equal(last.status,429);assert.equal(last.headers.get('retry-after'),'60');
});
test('page and assets are served with restrictive headers',async()=>{
  for(const path of ['/','/app.js','/style.css','/icon.svg']) {
    const response=await fetch(origin+path);assert.equal(response.status,200);assert.match(response.headers.get('content-security-policy'),/frame-ancestors 'none'/);assert.ok((await response.text()).length>0);
  }
  const page=await (await fetch(origin)).text();assert.match(page,/End session/);assert.match(page,/24 hours/);
  const response=await fetch(origin+'/../../etc/passwd');assert.equal(response.status,404);
});
